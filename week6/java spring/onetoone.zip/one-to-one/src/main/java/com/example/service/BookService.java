package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Book;
import com.example.entity.Story;
import com.example.repository.BookRepository;

@Service("BookInter")
public class BookService implements BookInter{
	
@Autowired
BookRepository bookRepository;


public Book saveBook(Book book) {

	Story story = book.getStory();
	story.setBook(book);
	book = bookRepository.save(book);
	return book;

}

public Book findByBookId(Long bookId) {
	Book book = bookRepository.findByBookId(bookId);
	return book;
}


}


