package com.example.service;

import org.springframework.stereotype.Component;

import com.example.entity.Book;

@Component
public interface BookInter {

	public Book saveBook(Book book);
	public Book findByBookId(Long bookId);
	
}
