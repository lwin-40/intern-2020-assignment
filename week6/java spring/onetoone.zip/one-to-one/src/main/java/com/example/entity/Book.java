package com.example.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name="BOOK")
@SequenceGenerator(name="seq", initialValue=1, allocationSize=100)
public class Book {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	Long bookId;

	@Column(name = "book_name")
	private String bookName;

	@OneToOne(cascade = CascadeType.ALL, mappedBy = "book")
	@JsonManagedReference
	private Story story;

	public Long getBookId() {
		return bookId;
	}

	public void setBookId(Long bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public Story getStory() {
		return story;
	}

	public void setStory(Story story) {
		this.story = story;
	}
	
	
}
