package com.example.service;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Phone;
import com.example.repository.PhoneRepository;
@Service
public class PhoneService {

	@Autowired
	PhoneRepository phoneRepository;

	public Phone save(Phone phone){
        return phoneRepository.save(phone);
    }

    public Collection<Phone> saveAll(Collection<Phone> phones){
        return phoneRepository.saveAll(phones);
    }

}
