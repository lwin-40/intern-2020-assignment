import java.util.ArrayList;
import java.util.List;

public class Admin {
public String admin_Id;
public String admin_UserName;
public String admin_Password;
List <Student> student=new ArrayList <Student>();
public List<Student> viewStudentForm() {
	return student;
}
public void confrimRegisterForm(){
	if(student!=null) {
		System.out.println("Confrim");
	}
	
}

public static void main(String args[]) {
	Student student=new Student();
	student.register();
	student.login();
	RegisterationForm registerationForm=new RegisterationForm();
	registerationForm.submit();
	Admin admin=new Admin();
	admin.viewStudentForm();
	admin.confrimRegisterForm();
}
}