
class Semesters {
	public String semester_Id;
	public String semester_Name;

}

public class Course {
	public String course_Id;
	public String course_Name;
	Semesters semester = new Semesters();
	Department deparment = new Department();

}

class Department {

	public String department_Id;
	public String department_Name;

}

class RegisterationForm extends Course {
	public void submit() {

		System.out.println("Successfully");
	}
}