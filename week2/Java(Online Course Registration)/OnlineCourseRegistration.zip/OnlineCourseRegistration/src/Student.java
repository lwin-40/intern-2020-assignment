
public class Student {
	public String student_Id;
	public String student_Name;
	public String student_Address;
	public String student_Phone;

	void register() {
		System.out.println("Successfully");
	}

	void login() {

		System.out.println("Successfully Login!");
	}

}
