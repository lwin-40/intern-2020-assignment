package com.example.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table ( name = "EMPLOYEE")
@SequenceGenerator(name="seq", initialValue=1, allocationSize=100)

public class Employee {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq")
	long id;
	
	@Column (name = "EMPLOYEE_NAME")
	 String name;
	@Column (name = "EMPLOYEE_ADDRESS")
	 String address;
	@Column (name = "EMPLOYEE_PHONE")
	 String phoneNo;
	@Column (name = "EMPLOYEE_SALARY")
	 String salary;
	
	public Employee() {
		super();
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	
}
