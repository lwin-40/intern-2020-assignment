package com.example.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Employee;
import com.example.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	public  List < Employee > getEmployee() {
		return employeeRepository.findAll();
	}
	
	public Employee addEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}
	
	public Employee findById(Long id) {
		return employeeRepository.findById(id).orElse(null);
	}
	
   public void deleteById(Long id) {
	   employeeRepository.deleteById(id);
   }
}
