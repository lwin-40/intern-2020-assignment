package RegistrationCourse.Controller;

import RegistrationCourse.entity.RegistrationForm;
import RegistrationCourse.entity.Student;

public class StudentController {

	public void register(Student student) {

	}

	public void login(Student student) {

	}

	public void submit(RegistrationForm registrationForm) {

	}
}
