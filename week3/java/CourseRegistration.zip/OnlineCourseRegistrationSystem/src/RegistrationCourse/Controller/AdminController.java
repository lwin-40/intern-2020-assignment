package RegistrationCourse.Controller;

import java.util.List;

import RegistrationCourse.entity.RegistrationForm;
import RegistrationCourse.entity.Student;

public class AdminController {

	public  void viewForm(List <Student> student) {

	}

	public void confirmRegisteration(List <RegistrationForm> registrationForm) {

	}
}