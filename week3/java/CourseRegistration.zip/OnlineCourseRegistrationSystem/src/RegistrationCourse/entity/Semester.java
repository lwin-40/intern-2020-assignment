package RegistrationCourse.entity;

public class Semester extends Course {

	public Semester() {
	}

	private int id;

	private String semesterName;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSemesterName() {
		return semesterName;
	}

	public void setSemesterName(String semesterName) {
		this.semesterName = semesterName;
	}

}